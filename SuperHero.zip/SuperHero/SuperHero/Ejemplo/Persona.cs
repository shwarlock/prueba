﻿namespace SuperHero.Ejemplo
{
    public class Persona
    {
        //Constructor
        //public Persona(string nombre)
        //{
        //    Nombre = nombre;
        //}
       
        //Atributos
        public string Nombre { get; set; }
        public int Edad   { get; set; }
        public float Altura { get; set; }
        public float Peso   { get; set; }
        
        //Metodos
        public string Presentarse()
        {
            return "Hola mi nombre es:" + Nombre;
        }
    }
}
