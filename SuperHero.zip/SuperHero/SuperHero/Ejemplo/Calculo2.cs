﻿namespace SuperHero.Ejemplo
{
    public class Calculo2 : ICalculo
    {
        public int Numero1 { get; set; }
        public int Numero2 { get; set; }
        public int Operacion()
        {
            return Numero1 * Numero2;
        }
    }
}
