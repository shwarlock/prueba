﻿using SuperHero.Datos;
using SuperHero.Datos.Entidades;
using SuperHero.DTO;

namespace SuperHero.Negocio 
{
    public class CategoriaNegocio : ICategoriaNegocio
    {
        private readonly ICategoriaRepositorio _categoriaRepositorio;

        public CategoriaNegocio(ICategoriaRepositorio categoriaRepositorio)
        {
            _categoriaRepositorio = categoriaRepositorio;
        }
        public List<CategoriaDTO> ObtenerCategorias()
        {
            var listaCategoriasDTO =new List<CategoriaDTO>();
            var listaEntidades =_categoriaRepositorio.ObtenerTodasLasCategorias();
            //mapeo entidades
            foreach (var categoriaEntidad in listaEntidades) 
            {
                var categoriaDTO = new CategoriaDTO { Id = categoriaEntidad.Id,Nombre = categoriaEntidad.Nombre };
                listaCategoriasDTO.Add(categoriaDTO);

            }

            return listaCategoriasDTO;
        }
        public void GuardarCategoria (CategoriaDTO categoriaDTO)
        {
            var entidad = new Categoria() { Nombre = categoriaDTO.Nombre };
            _categoriaRepositorio.GuardarCategoria(entidad);
        }
        public CategoriaDTO ObtenerCategoriaPorId(int id) 
        {
            var entidad = _categoriaRepositorio.ObtenerCategoriaPorId(id);
            var dto = new CategoriaDTO { Id = entidad.Id, Nombre = entidad.Nombre };
            return dto;
        }
        public void ActualizarCategoria(CategoriaDTO categoriaDTO)
        {
            var entidad = new Categoria() { Id=categoriaDTO.Id, Nombre = categoriaDTO.Nombre };
            _categoriaRepositorio.ActualizarCategoria(entidad);
        }

        public void EliminarCategoria(int id)
        {
            _categoriaRepositorio.EliminarCategoria(id);
        }
    }
}
