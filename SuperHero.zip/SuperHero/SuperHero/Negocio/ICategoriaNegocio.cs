﻿using SuperHero.DTO;

namespace SuperHero.Negocio
{
    public interface ICategoriaNegocio
    {
		void ActualizarCategoria(CategoriaDTO categoriaDTO);
		void EliminarCategoria(int id);
		void GuardarCategoria(CategoriaDTO categoriaDTO);
		CategoriaDTO ObtenerCategoriaPorId(int id);
		List<CategoriaDTO> ObtenerCategorias();
    }
}
