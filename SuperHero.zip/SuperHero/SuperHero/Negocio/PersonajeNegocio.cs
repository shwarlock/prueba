﻿using Microsoft.AspNetCore.Mvc.Rendering;
using SuperHero.Datos;
using SuperHero.DTO;

namespace SuperHero.Negocio
{
	public class PersonajeNegocio:IPersonajeNegocio
	{
		private readonly IPersonajeRepositorio _personajeRepositorio;
        private readonly ICategoriaRepositorio _categoriaRepositorio;

        public PersonajeNegocio(IPersonajeRepositorio personajeRepositorio,ICategoriaRepositorio categoriaRepositorio)
		{
			_personajeRepositorio = personajeRepositorio;
            _categoriaRepositorio = categoriaRepositorio;
        }
        public List<PersonajeListaDTO> ObtenerPersonajes()
        {
            var listaPersonajesDTO = new List<PersonajeListaDTO>();
            var listaEntidades = _personajeRepositorio.ObtenerTodosLosPersonajes();
            //mapeo entidades
            foreach (var PersonajeEntidad in listaEntidades)
            {
                var personajeListaDTO = new PersonajeListaDTO
                {
                    Id = PersonajeEntidad.Id,
                    Nombre = PersonajeEntidad.Nombre,
                    FechaNacimiento = PersonajeEntidad.FechaNacimiento,
                    Categoria = PersonajeEntidad.CategoriaNombre
                };
            listaPersonajesDTO.Add(personajeListaDTO);
            }

            return listaPersonajesDTO;
        }
        public SelectList ListarCategorias()
            {
            var categoriasEntidades = _categoriaRepositorio.ObtenerTodasLasCategorias();
            var SelectList = new SelectList(categoriasEntidades, "Id", "Nombre");
            return SelectList;
        }
    }
}
