﻿using Microsoft.AspNetCore.Mvc.Rendering;
using SuperHero.DTO;

namespace SuperHero.Negocio
{
	public interface IPersonajeNegocio
	{
		SelectList ListarCategorias();
		List<PersonajeListaDTO> ObtenerPersonajes();
	}
}
