﻿using SuperHero.Datos.Entidades;

namespace SuperHero.Datos
{
	public interface IPersonajeRepositorio
	{
		List<Personaje> ObtenerTodosLosPersonajes();
	}
}
