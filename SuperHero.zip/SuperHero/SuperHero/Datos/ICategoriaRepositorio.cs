﻿using SuperHero.Datos.Entidades;


namespace SuperHero.Datos
{
    public interface ICategoriaRepositorio
    {

		void ActualizarCategoria(Categoria categoria);
		void EliminarCategoria(int id);
		void GuardarCategoria(Categoria categoria);
		Categoria ObtenerCategoriaPorId(int id);
		public List<Categoria> ObtenerTodasLasCategorias();
      
    }
}
