﻿using Microsoft.Extensions.Configuration;
using SuperHero.Datos.Entidades;
using System.Data.SqlClient;

namespace SuperHero.Datos
{
	public class PersonajeRepositorio : IPersonajeRepositorio
	{
        private readonly IConfiguration _configuration;

        public PersonajeRepositorio(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public List<Personaje> ObtenerTodosLosPersonajes()
        {
            var listaPersonajes = new List<Personaje>();
            using SqlConnection sql = new SqlConnection(_configuration.GetConnectionString("ConexionPorDefecto"));
            using SqlCommand cmd = new SqlCommand("sp_obtener_todos_los_personajes", sql);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            sql.Open();
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var nuevoPersonaje = new Personaje
                    { Id = (int)reader["Id"],
                        Nombre = reader["Nombre"].ToString(),
                        NombreReal = reader["NombreReal"].ToString(),
                       // SuperPoder = reader["SuperPoder"].ToString(),
                        FechaNacimiento = reader["FechaNacimiento"] == DBNull.Value ? null : Convert.ToDateTime(reader["FechaNacimiento"]),
                        CategoriaId = (int)reader["CategoriaId"],
                        CategoriaNombre = reader["NombreCategoria"].ToString()


                    };
                    listaPersonajes.Add(nuevoPersonaje);
                }
            }


            return listaPersonajes;
        }
    }
}
