using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using SuperHero.Negocio;

namespace SuperHero.Pages
{
    public class nuevo_personajeModel : PageModel
    {
        private readonly IPersonajeNegocio _personajeNegocio;

        public nuevo_personajeModel(IPersonajeNegocio personajeNegocio)
        {
            _personajeNegocio = personajeNegocio;
        }
        public SelectList ListaCategorias { get; set; }
        public void OnGet()
        {
            ListaCategorias = _personajeNegocio.ListarCategorias();
        }
    }
}
