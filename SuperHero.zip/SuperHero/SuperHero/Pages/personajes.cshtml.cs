using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SuperHero.DTO;
using SuperHero.Negocio;

namespace SuperHero.Pages
{
    public class personajesModel : PageModel
    {
        private readonly IPersonajeNegocio _personajeNegocio;

        public personajesModel(IPersonajeNegocio personajeNegocio)
        {
            _personajeNegocio = personajeNegocio;
        }
        public List<PersonajeListaDTO> Personajes { get; set; }
        public void OnGet()
        {
            Personajes = _personajeNegocio.ObtenerPersonajes();
        }
    }
}
