using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SuperHero.Ejemplo;

namespace SuperHero.Pages
{
    public class PruebasModel : PageModel
    {
        private readonly ICalculo _calculo;

        public PruebasModel(ICalculo calculo)
        {
            _calculo = calculo;
        }
        public string Saludo1 { get; set; }
        public string Saludo2 { get; set; }
        public int Resultado { get; set; }
        public void OnGet()
        {

            var Persona1 = new Persona() { Nombre = "Juan", Altura = 1.8f, Edad = 27, Peso = 80 };
            var Persona2 = new Persona() { Nombre = "Maria", Altura = 1.6f, Edad = 22, Peso = 55};
            //Persona1.Nombre = "Juan";
            //Persona1.Altura = 1.8f;
            //Persona1.Edad = 27;
            ////Persona1.Peso = 80;
            var PresentacionPersona1 = Persona1.Presentarse();
            var PresentacionPersona2 = Persona2.Presentarse();
            Saludo1 = PresentacionPersona1;
            Saludo2 = PresentacionPersona2;

            
            _calculo.Numero1 = 5;
            _calculo.Numero2 = 10;
            var resultado = _calculo.Operacion();
            Resultado = resultado;


            //var Persona3 = new Persona("Pedro");
            //Persona3.Peso = 55;
        }
    }
}
