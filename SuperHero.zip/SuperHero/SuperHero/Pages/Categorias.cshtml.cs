using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SuperHero.DTO;
using SuperHero.Negocio;

namespace SuperHero.Pages
{

    public class categoriasModel : PageModel
    {
        private readonly ICategoriaNegocio _categoriaNegocio;

        public categoriasModel(ICategoriaNegocio categoriaNegocio)
        {
            _categoriaNegocio = categoriaNegocio;
        }
        public List<CategoriaDTO> Categorias { get; set;}
        public void OnGet()
        {
            Categorias = _categoriaNegocio.ObtenerCategorias();
        }
    }

}
