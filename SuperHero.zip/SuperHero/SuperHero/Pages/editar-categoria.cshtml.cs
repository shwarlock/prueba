using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SuperHero.DTO;
using SuperHero.Negocio;

namespace SuperHero.Pages
{
    public class editar_categoriaModel : PageModel
    {
        private readonly ICategoriaNegocio _categoriaNegocio;
        public editar_categoriaModel(ICategoriaNegocio categoriaNegocio)
        {
            _categoriaNegocio = categoriaNegocio;
        }
        [BindProperty]
        [Required(ErrorMessage = "El campo Nombre es requerido")]
        public string Nombre { get; set; }
        [BindProperty]
        public int Id { get; set; }
        public void OnGet(int id)
        {
            var dto = _categoriaNegocio.ObtenerCategoriaPorId(id);
            Id = id ;
            Nombre = dto.Nombre;
        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                var categoriaDTO = new CategoriaDTO() {Id = Id, Nombre = Nombre };
                _categoriaNegocio.ActualizarCategoria(categoriaDTO);
                return RedirectToPage("./Categorias");
            }
            return Page();
        }

    }
}
