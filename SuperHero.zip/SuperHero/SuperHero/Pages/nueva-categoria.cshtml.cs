using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SuperHero.DTO;
using SuperHero.Negocio;

namespace SuperHero.Pages
{
    public class nueva_categoriaModel : PageModel
    {
        private readonly ICategoriaNegocio _categoriaNegocio;
        public nueva_categoriaModel(ICategoriaNegocio categoriaNegocio)
        {
            _categoriaNegocio = categoriaNegocio;
        }
        [BindProperty]
        [Required (ErrorMessage ="El campo Nombre es requerido")]
        public String Nombre { get; set; }
        public void OnGet()
        {

        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                var categoriaDTO = new CategoriaDTO() { Nombre = Nombre };
                _categoriaNegocio.GuardarCategoria(categoriaDTO);
                return RedirectToPage("./Categorias");
            }
            return Page();
        }
    }
}
