﻿using System.ComponentModel.DataAnnotations;
using FantasySystemMVC.Entities;

namespace FantasySystemMVC.Models.DTOs
{
	public class ZodiacoDTO
    {
		public int Id { get; set; }
        //[Required(ErrorMessage = "El campo nombre es requerido")]
        //[MaxLength(50)]
        public string Nombre { get; set; }
        public string Signo { get; set; }
        public string Mes { get; set; }
        public int Rango { get; set; }
        public string Imagen { get; set; }
        public int CategoriaId { get; set; }



    }
}
