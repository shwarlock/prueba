﻿using System.ComponentModel.DataAnnotations;

namespace FantasySystemMVC.Models.DTOs
{
    public class CategoriaCreacionDTO
    {
        [Required (ErrorMessage ="El campo nombre es requerido")]
        [MaxLength(50)]
        public string Nombre { get; set; }
    }
}
