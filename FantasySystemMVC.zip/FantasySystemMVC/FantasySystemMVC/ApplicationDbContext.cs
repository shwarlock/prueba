﻿using FantasySystemMVC.Entities;
using Microsoft.EntityFrameworkCore;

namespace FantasySystemMVC
{
	public class ApplicationDbContext : DbContext
	{
		public ApplicationDbContext(DbContextOptions options) : base(options)
		{

		}

		public DbSet <Categoria> Categorias { get; set; }
		public DbSet <Zodiaco> Zodiacos { get; set; }
	}
	
}
