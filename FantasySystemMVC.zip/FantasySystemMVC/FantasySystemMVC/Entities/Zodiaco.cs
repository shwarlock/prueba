﻿using System.ComponentModel.DataAnnotations;

namespace FantasySystemMVC.Entities
{
	public class Zodiaco
	{

        public int Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string Nombre { get; set; }
        public string Signo { get; set; }
        public string Mes { get; set; }
        public int Rango { get; set; }
        public string Imagen { get; set; }
        public int CategoriaId { get; set; }
        public Zodiaco zodiaco { get; set; }


    }
}
