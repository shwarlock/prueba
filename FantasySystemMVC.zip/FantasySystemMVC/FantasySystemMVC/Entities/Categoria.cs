﻿using System.ComponentModel.DataAnnotations;

namespace FantasySystemMVC.Entities
{
	public class Categoria
	{
		public int Id { get; set; }
		[Required]
		[MaxLength(50)]
		public string Nombre { get; set; }
		public bool Activo { get; set; }

		public List<Zodiaco>Zodiaco { get; set; }
	
    }

}
