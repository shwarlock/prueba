﻿using AutoMapper;
using FantasySystemMVC.Entities;
using FantasySystemMVC.Models.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace FantasySystemMVC.Controllers
{
	public class CategoriasController : Controller 
	{
		private readonly ApplicationDbContext _context;
		private readonly IMapper _mapper;

		public CategoriasController(ApplicationDbContext context,IMapper mapper)
		{
			_context = context;
			_mapper = mapper;
		}
		public IActionResult Index()
		{
			var listaCategorias = _context.Categorias.Where(c => c.Activo == true).ToList();

			var listaCategoriasDTO = _mapper.Map<List<CategoriaDTO>>(listaCategorias);
			return View(listaCategoriasDTO);
		}
		public IActionResult Nuevo()
		{
			return View();
		}
		[HttpPost]
		public IActionResult Nuevo(CategoriaCreacionDTO model) 
		{
			if (ModelState.IsValid) 
			{
				//Guardar registro en BD
				var categoriaEntidad = _mapper.Map<Categoria>(model);
				categoriaEntidad.Activo = true;
				_context.Categorias.Add(categoriaEntidad);
				_context.SaveChanges();

				return RedirectToAction("Index");
			}
			return View(model);
		}
		public IActionResult Editar([FromRoute] int id) 
		{
			var categoriaEntidad = _context.Categorias.FirstOrDefault(c=>c.Id==id);
			var categoriaDTO = _mapper.Map<CategoriaDTO>(categoriaEntidad);
			return View(categoriaDTO);

		}

		[HttpPost]
		public IActionResult Editar (CategoriaDTO model) 
		{
            var categoriaEntidad = _context.Categorias.FirstOrDefault(c => c.Id == model.Id);
			categoriaEntidad.Nombre = model.Nombre;
			_context.SaveChanges();
            return RedirectToAction("Index");

        }
		public IActionResult Eliminar([FromRoute]int id)
		{
            var categoriaEntidad = _context.Categorias.FirstOrDefault(c => c.Id == id);
            var categoriaDTO = _mapper.Map<CategoriaDTO>(categoriaEntidad);
            return View(categoriaDTO);
		}

        [HttpPost]
        public IActionResult Eliminar(CategoriaDTO model)
        {
            var categoriaEntidad = _context.Categorias.FirstOrDefault(c => c.Id == model.Id);
			//_context.Categorias.Remove(categoriaEntidad);
			categoriaEntidad.Activo = false;
            _context.SaveChanges();
            return RedirectToAction("Index");

        }
	

    }
}
