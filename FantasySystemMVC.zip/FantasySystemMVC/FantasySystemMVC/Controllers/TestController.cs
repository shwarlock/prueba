﻿using FantasySystemMVC.Models.Test;
using Microsoft.AspNetCore.Mvc;

namespace FantasySystemMVC.Controllers
{
    public class TestController : Controller
    {
        public IActionResult  Index() 
        {
            return View();     
        }
        public IActionResult Prueba1()
        {
            var persona1 = new Persona() { Nombre = "Maria", Apellido = "Juarez", Edad = 12 };
            var persona2 = new Persona() { Nombre = "John", Apellido = "Wick", Edad = 42 };
            var listaPersonas = new List<Persona>() { persona1, persona2 };

            return View(listaPersonas);
        }
    }
}
