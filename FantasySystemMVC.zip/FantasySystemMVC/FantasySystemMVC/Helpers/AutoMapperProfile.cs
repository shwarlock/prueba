﻿using AutoMapper;
using FantasySystemMVC.Entities;
using FantasySystemMVC.Models.DTOs;

namespace FantasySystemMVC.Helpers
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Categoria, CategoriaDTO>();
            CreateMap<CategoriaCreacionDTO, Categoria>();
            CreateMap<Zodiaco, ZodiacoDTO>();
            CreateMap<ZodiacoDTO, Zodiaco>();
        }
    }
}
